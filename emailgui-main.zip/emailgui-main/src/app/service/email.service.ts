import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmailService {

  private baseUrl:string="http://localhost:8086/api/v1/movie"
  httpClient: any;
  constructor(private http:HttpClient) { }
  addUser(data:any)
  {
      return this.http.post(`${this.baseUrl}`,data)
  }
}
