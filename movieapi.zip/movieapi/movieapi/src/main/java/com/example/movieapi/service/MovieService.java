package com.example.movieapi.service;

import com.example.movieapi.model.Movie;
import java.util.List;

public interface MovieService {

	void addMovie(Movie movie);
	Movie getMovie(Movie movie);
	List<Movie> getAllMovie();
	Movie updateMovie(Movie movie);
	void deleteMovie(String email);
}
