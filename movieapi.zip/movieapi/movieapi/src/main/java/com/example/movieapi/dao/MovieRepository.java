package com.example.movieapi.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.movieapi.model.Movie;

@Repository
public interface MovieRepository extends JpaRepository<Movie, String> {

    Movie findByEmailAndPassword(String email, String password);

}
