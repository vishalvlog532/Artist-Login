package com.example.movieapi.controller;

import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.movieapi.model.Movie;
import com.example.movieapi.service.MovieService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("api/v1/")
public class UserController {
	
	private MovieService movieService;

	@Autowired
	public UserController(MovieService movieService) {
		super();
		this.movieService = movieService;
	}
	
	@PostMapping("movie")
	public ResponseEntity<?> addUser(@RequestBody Movie movie){
		
		movieService.addMovie(movie);
		
		return new ResponseEntity<>(HttpStatus.CREATED);
	}
	
	@GetMapping("/movie")
	public ResponseEntity<?> getAllUser(){
		
		return new ResponseEntity<>(movieService.getAllMovie(),HttpStatus.OK);
	}
	
	@DeleteMapping("/movie/{email}")
	public ResponseEntity<?> deleteUser(@PathVariable("email") String email){
		movieService.deleteMovie(email);
		return new ResponseEntity<>(HttpStatus.OK);
		
	}
	
	@PutMapping("/movie")
	public ResponseEntity<?> updateUser(@RequestBody Movie movie){
		
		return new ResponseEntity<>(movieService.updateMovie(movie),HttpStatus.CREATED);
	}

}



