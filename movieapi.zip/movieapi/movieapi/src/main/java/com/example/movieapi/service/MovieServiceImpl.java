package com.example.movieapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.movieapi.dao.MovieRepository;
import com.example.movieapi.model.Movie;

@Service
public class MovieServiceImpl implements MovieService {

	MovieRepository movieRepository;
	
	@Autowired
	public MovieServiceImpl(MovieRepository movieRepository) {
	
		this.movieRepository=movieRepository;
	}
	@Override
	public void addMovie(Movie movie) {
		// TODO Auto-generated method stub
		movieRepository.save(movie);
	}

	@Override
	public List<Movie> getAllMovie() {
		// TODO Auto-generated method stub
		return movieRepository.findAll();
		
	}

	@Override
	public Movie updateMovie(Movie movie) {
		// TODO Auto-generated method stub
		Movie movieData=movieRepository.findById(movie.getEmail()).orElse(null);
		if(movieData!=null) {
			movieData.setEmail(movie.getEmail());
			movieData.setPassword(movie.getPassword());
		}	
			return movieRepository.saveAndFlush(movieData);
		
	}

	@Override
	public void deleteMovie(String email) {
		// TODO Auto-generated method stub
		Movie movie=movieRepository.findById(email).orElse(null);	
		if(movie!=null) {
			movieRepository.delete(movie);
		}

	}
	@Override
	public Movie getMovie(Movie movie) {
		
		return movieRepository.findByEmailAndPassword(movie.getEmail(), movie.getPassword());
	}
		
	}

	
